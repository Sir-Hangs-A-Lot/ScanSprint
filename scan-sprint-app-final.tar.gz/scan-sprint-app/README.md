# ScanSprint

ScanSprint is a starter app that turns uploaded PDFs, TXT files, or pasted text into a sectioned RSVP reading dashboard.

## Included pieces

- FastAPI backend with:
  - `POST /api/parse-file` for `.pdf` and `.txt` uploads.
  - `POST /api/parse-text` for pasted text.
  - PDF body-text extraction with PyMuPDF.
  - Heuristic section detection for headings like Abstract, Introduction, Methods, Results, and Discussion.
  - Caption and reference filtering for common figure/table patterns.
- Frontend with:
  - Landing page split into upload and paste panels.
  - Left sidebar showing sections and paragraph nodes.
  - RSVP reader in the center.
  - Controls for WPM, font size, reader background, text color, and highlight color.
  - Fullscreen reader mode.
  - Light/dark theme toggle.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```

Then open `http://127.0.0.1:8000` in your browser.

## Notes

- This is a starter app, not a production parser.
- It works best with text-based PDFs rather than scanned image PDFs.
- The backend intentionally ignores image regions by extracting text blocks only.
- Caption filtering is heuristic, so visually complex layouts may still need stronger document parsing.
- For production, the next step would be a stronger section-extraction pipeline and optional AI cleanup of headings and paragraph grouping.


## Push and deploy

1. Create a GitHub repository and upload all files in this folder to the repository root.
2. In Render, create a new Web Service from that repository.
3. Render will detect `render.yaml` automatically if you deploy as a Blueprint, or you can copy the same values manually:
   - Build command: `pip install -r requirements.txt`
   - Start command: `uvicorn app:app --host 0.0.0.0 --port $PORT`
4. The Python version is pinned via `.python-version`.
5. After deploy, open the generated Render URL and test TXT and PDF uploads.
